create
    definer = vinay@localhost procedure find_employee_by_id(IN employee_id int)
BEGIN
        SELECT * FROM employees WHERE id= employee_id;
    end;

