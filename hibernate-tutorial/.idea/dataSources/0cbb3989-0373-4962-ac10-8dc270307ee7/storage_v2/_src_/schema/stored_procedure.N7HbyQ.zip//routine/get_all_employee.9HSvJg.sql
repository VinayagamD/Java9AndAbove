create
    definer = vinay@localhost procedure get_all_employee()
BEGIN
        SELECT * FROM employees;
    END;

