create
    definer = vinay@localhost procedure get_employee_count(OUT employee_count int)
BEGIN
        SELECT COUNT(*) INTO employee_count FROM employees;
    end;

