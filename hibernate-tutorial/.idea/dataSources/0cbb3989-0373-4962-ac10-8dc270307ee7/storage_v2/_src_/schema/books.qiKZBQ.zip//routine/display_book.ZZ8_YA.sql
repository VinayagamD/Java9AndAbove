create
    definer = root@localhost procedure display_book()
BEGIN
    SELECT * FROM books;
    END;

