create
    definer = root@localhost procedure disp_max(OUT highest_price decimal(10, 2))
BEGIN
    SELECT MAX(price) INTO highest_price FROM books;
    END;

