create
    definer = root@localhost procedure update_price(IN temp_isbn varchar(10), IN new_price decimal(10, 2))
BEGIN
	UPDATE books SET price=new_price WHERE isbn = temp_isbn;
    END;

