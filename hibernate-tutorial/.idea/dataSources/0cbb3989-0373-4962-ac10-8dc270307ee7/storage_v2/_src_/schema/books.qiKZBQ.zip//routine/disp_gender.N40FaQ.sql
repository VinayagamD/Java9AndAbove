create
    definer = root@localhost procedure disp_gender(INOUT mfgender int, IN emp_gender varchar(6))
BEGIN
		SELECT COUNT(gender) INTO mfgender FROM author WHERE gender = emp_gender;
    END;

